#CPE133-NoWinningAllowed
A puzzle game developed using VHDL in which the user must use switches on a Basys-3 board to match a pattern before time runs out.
